function openNav() {
    document.getElementById("mySidenav").style.width = "85%";
}
function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
}